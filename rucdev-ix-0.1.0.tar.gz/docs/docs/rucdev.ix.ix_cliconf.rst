.. _rucdev.ix.ix_cliconf:


************
rucdev.ix.ix
************

**Use ix cliconf to run command on NEC IX platform**


Version added: 0.1.0

.. contents::
   :local:
   :depth: 1


Synopsis
--------
- 











Status
------


Authors
~~~~~~~

- Yushi Takeda


.. hint::
    Configuration entries for each entry type have a low to high priority order. For example, a variable that is lower in the list will override a variable that is higher up.
